package com.example.music

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Retrofit

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    
    private lateinit var drawerlayout: DrawerLayout
    private lateinit var toolbar: Toolbar
    private lateinit var drawerToggle: ActionBarDrawerToggle
    private lateinit var navigationView: NavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initToolBar()
        navigationView.setNavigationItemSelectedListener(this)
//        navigationView.setCheckedItem(R.id.home_navi)
    }

    private fun initToolBar() {
        toolbar = findViewById(R.id.toolbar);
        drawerlayout = findViewById(R.id.drawerlayout)
        navigationView = findViewById(R.id.navi_view)
//        setSupportActionBar(toolbar)
        drawerToggle = ActionBarDrawerToggle(
            this,
            drawerlayout,
            toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        );
        drawerlayout!!.addDrawerListener(drawerToggle)
        drawerToggle.syncState()
    var retrofit : Retrofit

    }

    override fun onBackPressed() {
        if (drawerlayout!!.isDrawerOpen(GravityCompat.START)) {
            drawerlayout!!.closeDrawer(GravityCompat.START)
            return
        }
        super.onBackPressed()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.home_navi -> drawerlayout.closeDrawer(GravityCompat.START)
            R.id.infor_navi -> Toast.makeText(this, "thong tin", Toast.LENGTH_SHORT).show()
            else -> Toast.makeText(this, "123", Toast.LENGTH_SHORT).show()
        }
        drawerlayout.closeDrawer(GravityCompat.START)
        return true
    }
}
